<?php 
header("x-xss-protection: 1; mode=block");
header("x-frame-options: SAMEORIGIN");
header("x-content-type-options: nosniff");
header("x-content-type: nosniff");
header("x-powered-by: none");
header("Content-Security-Policy: Disclaimer: Entertainment only.");
?>