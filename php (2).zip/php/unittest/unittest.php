<?php

class Unit_Test extends \PHPUnit_Framework_Testcase{

    public function testTrueAssertstoTrue (){
        $this-->assertTrue (true);
    }

}
?>