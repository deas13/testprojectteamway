
<!DOCTYPE HTML> 
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap" rel="stylesheet">
<meta charset="UTF-8">
<meta name="Description" content="Free zodiac sign quiz and chat">
<meta name="Keywords" content="zodiac personality quiz, personality quiz, crush quiz, horoscope">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="style.css">

<title>Personality Quiz.  Is your crush a Capricorn?</title>
</head>

<body> 

<div id="intro">
<h1>Is your crush a Capricorn?</h1>
</div>
<div id="center">
<img src="images/capricorn.jpg" >
</div>
<br><br><br>
<div id="button">
<a href="http://localhost/php/index.php">Start
    </a>
</div>

<br><br><br><br>
<script>
  Insert google analytics script.
</script>

</body></html>