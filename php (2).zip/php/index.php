<!DOCTYPE HTML> 
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap" rel="stylesheet">
<meta charset="UTF-8">
<meta name="Description" content="Free zodiac sign quiz and chat">
<meta name="Keywords" content="zodiac personality quiz, personality quiz, crush quiz, horoscope">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="style.css">

<title>Personality Quiz.  What is your crush´s zodiac sign?</title>
</head>

<body> 

<div id="quizform">

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >

<?php
$i=0;
$e=0;
?>

<br><br>
<img src="images/zodiac.jpg" alt="Zodiac personality quiz.">
<br><br>
<br><br>

  1. Does your crush talk a lot about work, assets and hussle culture?
<br>
 <input type="radio" name="q1" <?php if(isset($_POST['q1']) && $_POST['q1']=="True") {echo "checked"; $i = $i + 1;} ?> value="True">True 
 <input type="radio" name="q1" <?php if (isset($_POST['q1']) && $_POST['q1']=="False") {echo "checked"; $e = $e + 1;} ?> value="False">False  
<br><br>

  2. Would your crush rather talk about himself and his achievements then ask you what did you eat at lunch?
<br>
 <input type="radio" name="q2" <?php if(isset($_POST['q2']) && $_POST['q2']=="True") {echo "checked"; $i = $i + 1;} ?> value="True">True 
 <input type="radio" name="q2" <?php if (isset($_POST['q2']) && $_POST['q2']=="False") {echo "checked"; $e = $e + 1;} ?> value="False">False  
<br><br>

  3. On a date, does he take you out to watch the sunset together?
<br />
 <input type="radio" name="q3" <?php if (isset($_POST['q3']) && $_POST['q3']=="True") {echo "checked"; $i = $i + 1;} ?> value="True">True 
 <input type="radio" name="q3" <?php if (isset($_POST['q3']) && $_POST['q3']=="False") {echo "checked"; $e = $e + 1;} ?> value="False">False 
<br><br>

4. Does he send you a good morning text?
<br />
 <input type="radio" name="q4" <?php if (isset($_POST['q4']) && $_POST['q4']=="True") {echo "checked"; $i = $i + 1;} ?> value="True">True
 <input type="radio" name="q4" <?php if (isset($_POST['q4']) && $_POST['q4']=="False") {echo "checked"; $e = $e + 1;} ?> value="False">False
<br><br>

5. Does he wear a lot of `smart`colors, like gray, blue, black or dark green?
<br />
 <input type="radio" name="q5" <?php if (isset($_POST['q5']) && $_POST['q5']=="True") {echo "checked"; $i = $i + 1;} ?> value="True">True
 <input type="radio" name="q5" <?php if (isset($_POST['q5']) && $_POST['q5']=="False") {echo "checked"; $e = $e + 1;} ?> value="False">False
<br><br>


<div id="button1">
<a href="http://localhost/php/results.php">
<input type="submit" name="submit" value="Submit">
    </a>
</div>

<br><br>
This site built by <a href="https://www.linkedin.com/in/dea-s-53702519a/">linkedin.com/in/dea-s-53702519a/</a>.

</form>
<br><br>
&copy; <?php echo date("Y")?>
</div>

<div id="results">

<?php
function ie($in,$em) {
     if ($in > $em) { echo "Capricorn!";}
     else { echo "not a Capricorn!";}
}


if (isset($_POST["submit"])) {

echo "YOUR QUIZ RESULTS!";
echo "<br>";
echo "Your crush is a ";
ie($i,$e);
echo "<br>";echo "<br>";
echo "Click the links below to find out more about your personality!";
echo "<br>";echo "<br>";
echo "<a href='https://www.astrosofa.com/horoscope/ascendant.html'>Ascendant sign</a>";
echo "<br>";echo "<br>";
echo "<a href='https://astro.cafeastrology.com/natal.php'>Birth chart calculator</a>";
echo "<br>";echo "<br>";
}

?>

</div>

<br><br><br><br>
<script>
  Insert google analytics script.
</script>
<body> 

</body></html>